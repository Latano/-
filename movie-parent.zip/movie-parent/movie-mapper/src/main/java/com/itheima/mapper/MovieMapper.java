package com.itheima.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.itheima.domain.Movie;
import org.springframework.stereotype.Repository;

@Repository
public interface MovieMapper extends BaseMapper<Movie> {
}
