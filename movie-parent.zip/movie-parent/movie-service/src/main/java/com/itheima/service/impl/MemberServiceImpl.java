package com.itheima.service.impl;

import com.itheima.domain.Member;
import com.itheima.mapper.MemberMapper;
import com.itheima.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class MemberServiceImpl implements MemberService {

    @Autowired
    private MemberMapper memberMapper;

    @Override
    public List<Member> findAll() {
        return memberMapper.selectList(null);
    }

    @Override
    public void save(Member member) {
        memberMapper.insert(member);
    }

    @Override
    public Member findById(Integer id) {
        return memberMapper.selectById(id);
    }

    @Override
    public void update(Member member) {
        memberMapper.updateById(member);
    }

    @Override
    public void deleteById(Integer id) {
        memberMapper.deleteById(id);
    }

    @Transactional
    @Override
    public void deleteByIds(Integer[] ids) {
        if (ids != null && ids.length > 0) {
            for (Integer id : ids) {
                memberMapper.deleteById(id);
            }
        }
    }
}