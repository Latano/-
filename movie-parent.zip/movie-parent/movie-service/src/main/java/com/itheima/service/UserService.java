package com.itheima.service;

import com.itheima.domain.User;

public interface UserService {

    //登录
    User login(String username, String password);
}
