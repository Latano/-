package com.itheima.service;

import com.itheima.domain.Member;
import com.itheima.domain.Movie;

import java.util.List;

public interface MemberService {

    //查询列表
    List<Member> findAll();

    //保存
    void save(Member member);

    //根据id查询
    Member findById(Integer id);

    //更新
    void update(Member member);

    //根据id删除
    void deleteById(Integer id);

    //根据id批量删除
    void deleteByIds(Integer[] ids);
}
