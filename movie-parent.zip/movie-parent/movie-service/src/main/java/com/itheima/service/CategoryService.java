package com.itheima.service;

import com.itheima.domain.Category;

import java.util.List;

//列表查询
public interface CategoryService {
     List<Category> findAll();

}
