package com.itheima.service;

import com.itheima.domain.Movie;

import java.util.List;

public interface MovieService {

    //查询所有
    List<Movie> findAll();

    //保存
    void save(Movie movie);

    //根据id查询
    Movie findById(Integer id);

    //修改
    void update(Movie movie);

    //根据id删除
    void deleteById(Integer id);

    //根据id数组删除
    void deleteByIds(Integer[] ids);

    //根据导航id查询影视列表
    List<Movie> findByCid(Integer cid);
}
