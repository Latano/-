package com.itheima.interceptor;

import com.itheima.common.JwtUtil;
import com.itheima.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

//拦截器：拦截请求，判断携带的token是否非法
@Component
public class LoginInterceptor implements HandlerInterceptor {

    @Autowired
    private UserService userService;
    //拦截之后的校验
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        //1.获取请求中携带的token
        String token = request.getHeader("token");
        //2.视图解析token，
        try {
            Map map = JwtUtil.parseToken(token);
            Object id = map.get("id");

            //如果成功，代表token合法，此时放行
            return true;
        }catch (Exception e){
            //如果校验失败，禁止通行，提示错误
            response.setStatus(401);//返回401状态码
            return false;
        }

    }
}
