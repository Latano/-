package com.itheima.interceptor;

import com.itheima.interceptor.LoginInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.ArrayList;

//配置
@Configuration
class ManagerConfig implements WebMvcConfigurer {

    @Autowired
    private LoginInterceptor loginInterceptor;

    //设置拦截器
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        //定义放行路径
        ArrayList<String> urls = new ArrayList<>();
        urls.add("/**/*.js");//管理系统静态资源
        urls.add("/**/*.css");//管理系统静态资源
        urls.add("/**/*.jpg");//管理系统静态资源
        urls.add("/**/*.png");//管理系统静态资源
        urls.add("/**/*.html");//管理系统静态资源
        urls.add("/admin/user/login");//管理系统登录请求
        urls.add("/admin/user/logout");//管理系统退出请求

        //配置拦截器和路径
        registry.addInterceptor(loginInterceptor)
                .addPathPatterns("/admin/**")//拦截所有
                .excludePathPatterns(urls); //放行指定路径
    }
}
