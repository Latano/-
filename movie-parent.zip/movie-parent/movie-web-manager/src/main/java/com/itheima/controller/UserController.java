package com.itheima.controller;

import com.itheima.common.JwtUtil;
import com.itheima.domain.User;
import com.itheima.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

//管理员
@RestController
public class UserController {

    @Autowired
    private UserService userService;

    //登录
    @RequestMapping("/admin/user/login")
    public Map<String,String> login(String username, String password) {

        //调用service进行登录操作
        User user = userService.login(username,password);

        Map<String,String> map = new HashMap<>();
        if (user == null) {//登陆失败
            map.put("code","0");
        }else {//登陆成功
            HashMap<String, Object> tokenMap = new HashMap<>();
            tokenMap.put("id",user.getId());
            String token = JwtUtil.createToken(tokenMap);
            System.out.println("得到的token是：" + token);

            map.put("token",token);
            map.put("code","1");
        }

        return map;
    }
}
