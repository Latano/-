package com.itheima.controller;

import com.itheima.domain.Member;
import com.itheima.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

//会员
@RestController
public class MemberController {

    @Autowired
    private MemberService memberService;

    //查询会员列表
    @RequestMapping("/admin/member/findAll")
    public List<Member> findAll() {
        return memberService.findAll();
    }

    //添加会员
    @RequestMapping("/admin/member/save")
    public void save(@RequestBody Member member) {
        if (member.getId() == null) { //无id,表示要新增
            memberService.save(member);
        } else {//有id,表示要更新
            memberService.update(member);
        }
    }

    //根据id查询
    @RequestMapping("/admin/member/findById")
    public Member findById(Integer id) {
        return memberService.findById(id);
    }

    //根据id删除
    @RequestMapping("/admin/member/deleteById")
    public void deleteById(Integer id) {
        memberService.deleteById(id);
    }

    //根据id批量删除
    @RequestMapping("/admin/member/deleteByIds")
    public void deleteById(Integer[] ids) {
        memberService.deleteByIds(ids);
    }
}
